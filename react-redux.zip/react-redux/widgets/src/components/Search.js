import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Search = () => {

    const [getTerm, setTerm] = useState('programming');
    const [getdebounce, setdebounce] = useState(getTerm);
    const [getResult, setResult] = useState([]);
 
    useEffect(() =>{
        const timeId = setTimeout(() =>{
            setdebounce(getTerm)
        }, 500);

        return () =>{
            clearTimeout(timeId);
        }
    },[getTerm]);

    useEffect(() =>{
        const search = async () =>{
            const { data } = await axios.get('https://en.wikipedia.org/w/api.php', {
                params: {
                    action: 'query',
                    list: 'search',
                    origin: '*',
                    format: 'json',
                    srsearch: getdebounce,

                },
            });
            setResult(data.query.search);
        }
        search();
    }, [getdebounce])

    useEffect(() => {
        // Three way of invokes functions.
    // 1.   (async () =>{
    //        await axios.get();
    //invoke immediately    })();

    //2. const search = async () =>{ await axios.get(''); };
        // search();
    // 3. axios.get('url').then((response)=>{console.log(response.data);})
        // const search = async () =>{
        //     const { data } = await axios.get('https://en.wikipedia.org/w/api.php', {
        //         params: {
        //             action: 'query',
        //             list: 'search',
        //             origin: '*',
        //             format: 'json',
        //             srsearch: getTerm,

        //         },
        //     });
        //     setResult(data.query.search);
        // }

        // if(getTerm && !getResult.length){
        //     search();
        // }else{
        //     const timmerId = setTimeout(() => {
        //         if(getTerm)search();
        //     }, 500);
        
        //        return () => {
        //            clearTimeout(timmerId);
        //        };
        // }
     
    }, [getTerm, getResult.length]);

    const renderResult = getResult.map(item => {
        return (
            <div className="item" key={item.pageid}>
                <div style={{display: 'block', textAlign: 'end'}}>
                   <a name="" id="" className="btn btn-primary" href="https://en.wikipedia.org/w/api.php" role="button">GO</a> 
                </div>
                <div className="content">
                    <div className="header">
                    <h3>{ item.title }</h3>
                    </div>
                    <div>
                    <span dangerouslySetInnerHTML={{ __html: item.snippet}}></span>
                    </div>
                </div>
            </div>
        );
    });

    return(
        <div className="ui segment">
            <div className="ui form">
                <div className="field">
                  <label>Enter Search Term</label>
                  <input 
                  className="input"
                  value={getTerm}
                  onChange={e=> setTerm(e.target.value)}  />  
                </div>
            </div>
            <div className="ui celled list">
                { renderResult }
            </div>
        </div>
    );
}

export default Search;