import React, { useState } from 'react';
import Accordion from './Accordion';
import Search from './Search';
import Dropdown from './dropdown';
import Translate from './Translate';
import Route from './Route';
import HeaderMenu from './header';

const items = [
    {
        title: 'What is React?',
        content: 'React is afront-end JavaScript framework'
    },
    {
        title: 'Why use React ?',
        content: 'React is a favorite JS library among engineers'
    },
    {
        title: 'How do you use React?',
        content: ' You use React by creating components'
    }
];

const options = [
    {
        label: 'The color is Red',
        value: 'red'
    },
    {
        label: 'The color is Blue',
        value: 'blue'
    },
    {
        label: 'The color is Yellow',
        value: 'yellow'
    }
];


const App = () => {
 
    const apikey = "AIzaSyCHUCmpR7cT_yDFHC98CZJy2LTms-IwDlM";
    const [selected, setSelected] = useState(options[0]);

    return(
    <div>
        <HeaderMenu />
        <Route path="/">
            <Accordion items={items} />
        </Route>
        <Route path="/list">
            <Search />
        </Route>
        <Route path="/translate">
            <Translate />
        </Route>
        <Route path="/dropdown">
            <Dropdown 
            label="Select a color"
            selected={selected} 
            onSelectedChange={setSelected}
            options={options}
            />
        </Route>
       
       {/* <Accordion items={ items } />  */}
       {/* <Dropdown 
       label="Select a color",
       selected={selected} 
       onSelectedChange={setSelected}
       options={options}
       /> */}
        {/* <Search /> */}
        {/* <Translate /> */}


        {/* <div>
               
               <h3>Concept covered</h3>
               <ul>
               <li>Search</li>
                   <li>UseState</li>
                   <li>UseEffect</li>
                   <li>UseRef</li>
                   <li>Drop down</li>
                   <li>Translate</li>
               </ul>
           </div> */}
    </div>
    );

}

export default App;
