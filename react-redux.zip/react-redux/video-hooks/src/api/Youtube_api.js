import axios from 'axios';

const KEY = 'AIzaSyB7_enq6376VOVtvihBPg8lcEE2ls6ARAU';

export default axios.create({
    baseURL : 'https://www.googleapis.com/youtube/v3',
    params: {
        part: 'snippet',
        maxResults: 5,
        key: KEY,
    }
});
