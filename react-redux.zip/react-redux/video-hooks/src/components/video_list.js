import React from 'react';
import VideoItems from './Video_items';
const VideoList = ({ videos, onSelected_video}) => {
    
    const render_list = videos.map(video => {
      
        return <VideoItems onSelected_video={onSelected_video} videoitems={ video } key={ video.id.videoId }/>
    });
    // if(videos.length === 0) return<div>Loading..</div>

    return(
            <div>
                {videos.length !== 0 ?
                <div className="ui segment relaxed divided list">
                { render_list  } 
                </div>
                : 
                ""
                }
            </div>
    );
}
export default VideoList;
