import React from 'react';
import './videodetails.scss';

const Video_details = ({ video }) => {
if(!video)return <div><div className="arc"></div><h1><span>LOADING</span></h1></div>;
const videosrc = `https://www.youtube.com/embed/${video.id.videoId}`;
    return(
        <div>
            <div className="ui embed">
                <iframe src={ videosrc } title={ video.snippet.title }></iframe>
            </div>
            <div className="ui segment">
                <h4 className="ui header">{ video.snippet.title }</h4>
                <p>{ video.snippet.description }</p>
            </div>
        </div> 
    );
}

export default Video_details;