import './Video_items.css';
import React from 'react';

const VideoItems = ({videoitems, onSelected_video}) => {
    
    return(
            <div onClick={() => onSelected_video(videoitems)} className="video_item item">
                <img className="ui image" src={videoitems.snippet.thumbnails.medium.url} 
                 alt={ videoitems.snippet.description }/>
                <div className="content">
                <div className="header">{videoitems.snippet.title }</div>
                </div>
            </div>
    );
}

export default VideoItems;
