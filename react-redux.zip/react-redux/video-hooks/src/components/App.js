import React ,{useState, useEffect} from 'react';
import Searchbar from './Searchbar';
import useVideos from '../hooks/useVideo';
import VideoList from './video_list'
import Videodetails from './Videodetails';

const App = () => {
    
    const [selectedVideo, setselectedVideo] = useState(null);
    const [videos, onSearch] = useVideos('cars');

    useEffect(() =>{
        setselectedVideo(videos[0]);
    }, [videos]);
   
        return(
            <div className="ui container">
                <Searchbar onFormsubmited={ onSearch }/>
             <div className="ui grid">
                 <div className="ui row">
                    <div className="eleven wide column">
                         <Videodetails video={selectedVideo}/>
                    </div>
                    <div className="five wide column">
                         <VideoList videos={videos}
                        onSelected_video={ (video) => setselectedVideo(video) } />
                    </div>
                 </div>    
             </div>
            </div>
        );
}
export default App;