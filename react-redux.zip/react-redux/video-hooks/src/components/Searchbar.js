import React, {useState} from 'react';


const SearchBar = ({onFormsubmited}) =>{

    const [getSearchInput,setSearchInput] = useState('');

    const onFormsubmit = (event) => {
        event.preventDefault();
        onFormsubmited(getSearchInput);
    };
        return(
            <div className=" ui segment search_bar">
                <form onSubmit={onFormsubmit} className=" ui form">
                    <div className="field">
                        <label>Search for a videos</label>
                        <input type="text" value={getSearchInput} onChange={(event)=>setSearchInput(event.target.value) }/>
                    </div>
                </form>
            </div>
        );
}

export default SearchBar;