import { useState, useEffect } from "react";
import YoutubeApi from "../api/Youtube_api";
// Custom hooks
const useVideos = (defaultSerchterm) =>{

    const [list_of_video, setlist_of_video] = useState([]);

    useEffect(() =>{
        onSearch(defaultSerchterm);
   }, [defaultSerchterm]);

   const onSearch = async term => {
       const response = await YoutubeApi.get('/search', {
           params: {
               q: term
           }
       });
       setlist_of_video(response.data.items);
    };
   return [list_of_video, onSearch];
};

export default useVideos;


