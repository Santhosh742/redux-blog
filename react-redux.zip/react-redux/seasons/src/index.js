import React from 'react';
import ReactDOM from 'react-dom';
import SeasonDisplay from './displaySeason';
import Spinner_icon from './spinner';
// const App = () => {
//     window.navigator.geolocation.getCurrentPosition(
//         position => console.log(position),
//         err => console.log(err)
//     );
//     return (
//         <div> Hi React </div>
//     );
// }

class App extends React.Component{
    // constructor(props){
    //     super(props);
    //     this.state ={ lat : null, errorMessage: '' };

    // }
    // Equalent to constructor intialisation.
    state = { lat: null, errorMessage: ''};

    componentDidMount(){
        window.navigator.geolocation.getCurrentPosition(
            position => this.setState({lat : position.coords.latitude}),
            err =>  this.setState({ errorMessage: err.message})
        );
    }

    renderContent() {
        if(this.state.lat && !this.state.errorMessage){
            return <SeasonDisplay lat={this.state.lat} />;
        }

        if(!this.state.lat && this.state.errorMessage){
            return <div> 
                Error : {this.state.errorMessage}
                </div>;
        }

        if(!this.state.lat && !this.state.errorMessage){
            return <Spinner_icon message="Please allow the location request"/>;
        }
    }
  
    render() {
        return(
            <div style={{border: '4px solid red'}}>
                {this.renderContent()}
            </div>
        );
       
    // return(
    //     <div>
    //         {this.state.lat!==null ?
    //         <div>Latitude: { this.state.lat }</div> 
    //         : 
    //         <div> Error : { this.state.errorMessage}</div>
    //         }
    //     </div>
    // );
    }
}
ReactDOM.render( <
    App / > , document.querySelector('#root')
);