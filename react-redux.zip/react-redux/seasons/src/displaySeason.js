import './seasons.css';
import React from 'react';

const seasonConfig = {
    summer: {
        seasons_time : "Let's hit the beach",
        season_Icon : "massive orange  sun icon"
    },
    winter : {
        seasons_time : "Burr, it is chilly",
        season_Icon : "massive teal snowflake icon"
    }
}

const getSeason = (lat, mnth) => {
    if(mnth > 2 && mnth < 9){
      return lat > 0 ? 'summer' : 'winter';
    } else {
      return lat > 0 ? 'winter' : 'summer';
    }
}

const Displayseason = props =>{
    const setSeason = getSeason(props.lat, new Date().getMonth());
    const {seasons_time, season_Icon} = seasonConfig[setSeason]; //Destructure and return the text and icons
    console.log(setSeason);
    return(
        <div className={`display_season ${setSeason}`}>
           
            <i className={`icon_left ${season_Icon}`} />
            <h1>{ seasons_time }</h1>
            <i className={`icon_right ${season_Icon}`} />
        </div>
        
    );
}

export default Displayseason;