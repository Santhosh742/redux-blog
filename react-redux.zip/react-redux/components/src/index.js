import React from 'react';
import ReactDOM from 'react-dom';
import CommentDetails from './comment-dtl';
import faker from 'faker';
import Approvecard from './approvalCard';

const App = () =>{
    const comment_details ={
        alldetail: [
            {img: faker.image.avatar(), name: "sam", date_time: "5min ago", comment: "Product was very good!!",
            subDetail: [
                        {area: "Mangalore", state: "Karnataka"}
                       ]
            },
            {img: faker.image.avatar(), name: "Alex", date_time: "Today 6PM", comment: "Worth product!!",
            subDetail: [
                        {area: "Mangalore", state: "Karnataka"}
                       ]
            },
            {img: faker.image.avatar(), name: "Glen", date_time: "30 May 2021", comment: "Color was similar what showed in website!!",
                subDetail: [
                    {area: "Mangalore", state: "Karnataka"}
                           ]
            }
                     ],
        empty_details:[]

    };
    return (
            <div className="ui container comments">
            <Approvecard>
                <div>
                    <h4 className="wran"> Warning!!</h4>
                    Are you sure !!!
                </div>
            </Approvecard>
              <CommentDetails details={comment_details} />
            </div>
    );
};

ReactDOM.render(<App/>, document.querySelector("#root"));