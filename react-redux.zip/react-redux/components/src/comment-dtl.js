import {React, useState} from 'react';
import Approvecard from './approvalCard';

const CommentDetails = (props) => {
 const [detail_val] = useState(props.details.alldetail);
   return(<div>
     {detail_val.length!==0 ? 
     <>
     {detail_val.map((animal,index)=>(
         <Approvecard>
        <div className="comment" key={index}>
        <a href="/" className="avatar">
            <img  alt="avatar" src={animal.img}/>
        </a>
        <div className="content">
            <a href="/" className="author">
                {animal.name}
            </a>
            <div className="metadata">
                <span className="date">
                    {animal.date_time}
                </span>
            </div>
            <div className="text">{animal.comment}</div>
        </div>
    </div>   
    </Approvecard>
     ))}
      
      </>  
        : 
"No Data Available"
     }
        
        </div> 
    )
}

export default CommentDetails; 

