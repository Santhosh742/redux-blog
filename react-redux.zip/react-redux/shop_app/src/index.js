// Import the react and reactDOM libraries
import React from 'react';
import ReactDOM from 'react-dom';

function getbtn_nam() {
    return 'Click me!'
}

// Create a react component
const App = () => {
    const inputval = "Name of the person";
    const style = {
        label:{color: 'blue'},
        button_sub: { background: "yellow", color: "red"}
    }
    const label_name = "Enter Name";
   return <div>Hi There!!
    <div style={{color: 'red'}}>
        
        
       <label style={style.label} htmlFor="name">{label_name}</label>
            <input className="form-control" placeholder={inputval}></input>
             <button type="button" style={style.button_s} className="btn btn-success">{getbtn_nam()}</button>
            
       
        
        
    </div>
    </div>;
};

// Take the react component and show it on the screen

ReactDOM.render(
    <App />, 
    document.querySelector('#root')
);