import axios from 'axios';

export default axios.create({
    baseURL : 'https://api.unsplash.com',
    headers: {
        Authorization: 'Client-ID tYkBZGx8Use4UsPdxNNWScHpO100aWo-PMVoMz9a2bA' 
    }
});