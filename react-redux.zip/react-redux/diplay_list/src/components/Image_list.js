import React from 'react';
import ImageCard from './ImageCard';

const ImageList = (props) => {
    const list_items =  props.imageslist.map((image) => {
        return (
            <ImageCard  key={image.id} image={ image }/>
        );
 }); 
    // const list_items =  props.imageslist.map(({urls, alt_description, id}) => {
    //         return (
    //             <div className="image" key={id}>
    //             <img src={ urls.regular } alt={alt_description}/>
    //             </div>
    //         );
    //  }); 
        return(
                <div className="grid_container">
                     { list_items } 
                </div>
              );
}

export default ImageList;