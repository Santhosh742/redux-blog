import React from 'react';
import Unsplash from '../api/unsplash';
import Searchbar from './Searchbar';
import Imagelist from './Image_list';

class App extends React.Component{
    state = { list_pics : []}

 onSearchSubmit = async term => {
     const response = await Unsplash.get('/search/photos', {
            params: { query: term }   
       });
       this.setState({ list_pics : response.data.results });
    };
    
    render(){
        return(
                <div className="ui container" style={{marginTop: "10px"}}>
                    <Searchbar onSubmitsearch={this.onSearchSubmit} />
                    <Imagelist imageslist ={ this.state.list_pics } />
                </div>  
             );
    }  
}
 export default App;