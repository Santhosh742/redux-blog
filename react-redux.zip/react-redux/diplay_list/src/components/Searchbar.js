import React from 'react';

class Search_bar extends React.Component{
  
 state = {term: ''};
// onInputChange(event) {
// event.preventDefault();
// console.log(event.target.value)
// }

// onInputClick(){
// console.log('Input Clicked....')
// }

onFormSubmit = (event) => {
    event.preventDefault();
    // console.log(this.state.term);
    this.props.onSubmitsearch(this.state.term)
}

// onFormSubmit(event){
//     event.preventDefault();
//     console.log(this.state.term);
// }

    render(){
        return (
                <div className="ui segment">
                    {/* <form className="ui form" onSubmit={(event) => this.onFormSubmit(event)}> */}
                    <form className="ui form" onSubmit={this.onFormSubmit}>
                        <div className="field">
                            <label>Image Search</label>
                            <input type="text"
                            value={this.state.term}
                            onChange={(e) => this.setState({ term : e.target.value })}
                            //  onChange={this.onInputChange}
                            // onClick={this.onInputClick}
                            // onChange={(e)=>console.log(e.target.value.toUpperCase())} 
                             />
                        </div>
                    </form>
                </div>
        );
    }
}

export default Search_bar;
