import React from 'react';
import Searchbar from './Searchbar';
import YoutubeApi from '../api/Youtube_api';
import VideoList from './video_list'
import Videodetails from './Videodetails';

class App extends React.Component {

    state = { list_of_video: [], selectedVideo: null };

componentDidMount(){
    this.onTermSubmit('buildings');
}

   onTermSubmit = async term => {
       const response = await YoutubeApi.get('/search', {
           params: {
               q: term
           }
       })
       this.setState({ 
           list_of_video : response.data.items,
           selectedVideo: response.data.items[0]
        });
    };

    onSelected_video = (video) => {
        this.setState({ selectedVideo : video});
    }

    render() {
        return(
            <div className="ui container">
                <Searchbar onFormsubmited={ this.onTermSubmit }/>
             <div className="ui grid">
                 <div className="ui row">
                    <div className="eleven wide column">
                         <Videodetails video={ this.state.selectedVideo}/>
                    </div>
                    <div className="five wide column">
                         <VideoList videos={this.state.list_of_video}
                        onSelected_video={ this.onSelected_video } />
                    </div>
                 </div>    
             </div>
            </div>
        );
    }
}
export default App;