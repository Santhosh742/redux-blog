import React from 'react';


class SearchBar extends React.Component{

    state = { searchInput : ''};

    onChange_Search = (event) => {
        this.setState({ searchInput : event.target.value });
    };

    onFormsubmit = (event) => {
        event.preventDefault();
        this.props.onFormsubmited(this.state.searchInput);
    };

    render(){ 
        return(
            <div className=" ui segment search_bar">
                <form onSubmit={this.onFormsubmit} className=" ui form">
                    <div className="field">
                        <label>Search videos</label>
                        <input type="text" value={this.state.searchInput} onChange={ this.onChange_Search }/>
                    </div>
                </form>
            </div>
        );
    }
}

export default SearchBar;