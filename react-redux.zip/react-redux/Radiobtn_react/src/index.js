import React from "react";
import { render } from "react-dom";

const json = {
  question: "Do you support cookies in cakes?",
  choices: [
    { text: "Yes", value: "1" },
    { text: "No", value: "2" }
  ]
};

const PollOption = ({ options, selected, onChange }) => {
  return (
    <div className="pollOption">
      {options.map((choice, index) => (
        <label key={index}>
          <input
            type="radio"
            name="vote"
            value={choice.value}
            key={index}
            checked={selected === choice.value}
            onChange={onChange}
          />
          {choice.text}
        </label>
      ))}
    </div>
  );
};

class OpinionPoll extends React.Component {
  constructor(props) {
    super(props);
    this.state = { selectedOption: "1", showhide: true };
  }

  handleClick() {
    console.log("submitted option", this.state.selectedOption);
  }

  handleOnChange(e) {
    this.setState({ selectedOption: e.target.value });

    if (e.target.value === "1") {
      console.log("New");
      this.setState({ showhide: true });
    } else {
      console.log("New1");
      this.setState({ showhide: false });
    }
    console.log("selected optionsss", e.target.value);
  }

  render() {
    return (
      <div className="poll">
        {this.props.model.question}
        <PollOption
          options={this.props.model.choices}
          onChange={(e) => this.handleOnChange(e)}
          selected={this.state.selectedOption}
        />

        <button onClick={() => this.handleClick()}>Vote!</button>
        <div style={{ display: this.state.showhide ? "block" : "none" }}>
          YES
        </div>
        <div style={{ display: this.state.showhide ? "none" : "block" }}>
          NO
        </div>
      </div>
    );
  }
}

render(<OpinionPoll model={json} />, document.getElementById("root"));

// const PollOption = ({ options, onChange }) => {
//   return (
//     <div className="pollOption">
//       {options.map((choice, index) => (
//         <label key={index}>
//           <input type="radio"
//             name="vote"
//             value={choice.value}
//             key={index}
//             defaultChecked={choice.value}
//             onChange={(e) => onChange(e.target.value)} />
//           {choice.text}
//         </label>
//       ))}
//     </div>
//   );
// };
// class OpinionPoll extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = { selectedOption: '' }
//   }

//   handleClick() {
//     console.log('button clicked');
//   }

//   handleOnChange(val) {
//     console.log('foo', val);
//   }

//   render() {
//     return (
//       <div className="poll">
//         {this.props.model.question}
//         <PollOption
//           options={this.props.model.choices}
//           onChange={(val) => this.handleOnChange(val)} />

//         <button onClick={() => this.handleClick()}>Vote!</button>
//       </div>
//     );
//   }
// }

// render(<OpinionPoll model={json} />, document.getElementById('root'));
